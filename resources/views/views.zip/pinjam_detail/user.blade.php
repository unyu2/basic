<div class="modal fade" id="modal-user" tabindex="-1" role="dialog" aria-labelledby="modal-user">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Pilih User</h4>
            </div>
            
            <div class="modal-body">
            <table class="table table-stiped table-bordered table-user" style="width:100%">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th>NIP</th>
                <th>Nama</th>
                <th width="15%"><i class="fa fa-cog"></i></th>
            </tr>
        </thead>
        <tbody>
            <!-- Data diisi melalui AJAX -->
        </tbody>
    </table>
            </div>
        </div>
    </div>
</div>