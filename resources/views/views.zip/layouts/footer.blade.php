<footer class="main-footer">
    <div class="pull-right hidden-xs">
    *Technology Digital Platform.<b> Draft Sample Design Output</b>
    </div>
    <strong>Copyright &copy; {{ date('Y') }}.<a href="/"> Technology Process Management & RAMS</a>.</strong> All rights
    reserved.
</footer>