<div class="modal fade" id="modal-supplier" tabindex="-1" role="dialog" aria-labelledby="modal-supplier">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Pilih Supplier</h4>
            </div>
            
            <div class="modal-body">
            <table id="table1" class="tableSupplier table-stiped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th>Nama Supplier</th>
                <th width="15%"><i class="fa fa-cog"></i></th>
            </tr>
        </thead>
        <tbody>
            <!-- Data diisi melalui AJAX -->
        </tbody>
    </table>
            </div>
        </div>
    </div>
</div>